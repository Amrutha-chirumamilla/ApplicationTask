package com.example.androidtask

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var numberAdapter: NumberAdapter
    private lateinit var rulesSpinner: Spinner
    private var currentRule: Rule = Rule.Odd

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 10) // 10 columns for the grid
        numberAdapter = NumberAdapter(getNumbers(), currentRule)
        recyclerView.adapter = numberAdapter

        // Initialize Spinner for rule selection
        rulesSpinner = findViewById(R.id.rulesSpinner)
        setupSpinner()

        // Update adapter when rule is changed
        rulesSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                currentRule = Rule.values[position]
                numberAdapter = NumberAdapter(getNumbers(), currentRule)
                recyclerView.adapter = numberAdapter
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun getNumbers(): List<Int> {
        return (1..100).toList() // Generates numbers from 1 to 100
    }

    private fun setupSpinner() {
        val ruleNames = Rule.values.map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, ruleNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        rulesSpinner.adapter = adapter
    }
}