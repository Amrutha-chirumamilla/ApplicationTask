package com.example.androidtask

sealed class Rule(val name: String) {
    object Odd : Rule("Odd") {
        fun isNumberHighlighted(number: Int): Boolean = number % 2 != 0
    }

    object Even : Rule("Even") {
        fun isNumberHighlighted(number: Int): Boolean = number % 2 == 0
    }

    object Prime : Rule("Prime") {
        fun isNumberHighlighted(number: Int): Boolean = isPrime(number)

        private fun isPrime(num: Int): Boolean {
            if (num < 2) return false
            for (i in 2 until num) {
                if (num % i == 0) return false
            }
            return true
        }
    }

    object Fibonacci : Rule("Fibonacci") {
        fun isNumberHighlighted(number: Int): Boolean = isFibonacci(number)

        private fun isFibonacci(num: Int): Boolean {
            var a = 0
            var b = 1
            while (a < num) {
                val temp = a
                a = b
                b = temp + b
            }
            return a == num
        }
    }

    companion object {
        val values = listOf(Odd, Even, Prime, Fibonacci)
        fun isNumberHighlighted(rule: Rule, number: Int): Boolean {
            return when (rule) {
                Odd -> Odd.isNumberHighlighted(number)
                Even -> Even.isNumberHighlighted(number)
                Prime -> Prime.isNumberHighlighted(number)
                Fibonacci -> Fibonacci.isNumberHighlighted(number)
            }
        }

    }
}


